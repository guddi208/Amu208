package com.gcc.connector.Config;

public class PD5_Testrail_Common_properties {
	public  final static String  idTestPlan= "5296";
	public  final static String   idBuild= "GCC_20.19.9_RC1_DEMO";
	public  final static String  assignedTo= "81";
}
